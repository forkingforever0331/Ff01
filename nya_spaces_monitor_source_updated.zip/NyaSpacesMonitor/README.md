# Nya Spaces Monitor — Android-only source project

A **phone-only Android app** (Kotlin + Jetpack Compose) that checks whether **@nya0331** has started hosting an X Space. The app has no backend, Firebase, cloud scheduler, scraping, or telemetry. It uses the official X API, locally scheduled `AlarmManager.setAndAllowWhileIdle` alarms, WorkManager for network work, Android's `NotificationManager`, SharedPreferences, and Android Keystore encryption.

**Status (November 3, 2026):** source implemented, scheduling/filter smoke checks passed using a standalone Kotlin compiler. **Not built into an APK or tested on a real Android phone. Not tested against live X API because no developer Client ID, authorized login, or endpoint entitlement was supplied.** Do not treat it as a verified production installation.

## Requirements

- Android 8.0 or later (API 26+); best tested on Samsung Galaxy / Android 16.
- Android Studio with Android SDK Platform 36, JDK 17, Gradle 8.13, Kotlin 2.2.21 support.
- X Developer account, a *public/native* OAuth 2.0 application with Client ID and permission/credits to use `GET /2/spaces/by/creator_ids` and user lookup.
- Internet access on the phone; no external server is required.

## 1. X Developer setup

1. Go to the official [X Developer Console](https://developer.x.com/). Create an X API application and check that the current paid API access allows Spaces lookup. Do not assume the endpoint is accessible merely because it is documented.
2. Enable **OAuth 2.0**, choose **Native App / public client**, and register this **exact callback URI**:

   `com.example.nyaspaces://oauth/callback`

3. Configure the scopes `space.read`, `users.read`, `tweet.read`, and `offline.access` if available for your developer project. These allow Space lookup, username resolution, and refresh tokens.
4. Copy the **Client ID**, not the Client Secret. No secret is embedded in the APK. If the provider rejects the callback URI or the Native App option, direct access is blocked for this configuration; change only the redirect/native registration after validating X's current instructions.
5. Confirm the current **cost per endpoint/resource in the X Developer Console**; the publicly documented pay-per-use model does not provide a reliable fixed monthly Spaces cost. The app targets 7 requests per night, or approximately **210 Space-lookup requests per 30 days** (plus an initial username resolution, OAuth refreshes and manual requests). Failed/late alarms may reduce the total.

Official reference: https://docs.x.com/x-api/spaces/get-spaces-by-creator-ids

## 2. Build and install

Open the `NyaSpacesMonitor` project folder in **Android Studio**. Allow Gradle dependency sync; build a debug APK using **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The resulting path should be `app/build/outputs/apk/debug/app-debug.apk` if the build succeeds.

**Gradle wrapper note:** This archive has no `gradle-wrapper.jar` binary because the build environment cannot download verified binaries. On a developer computer with Gradle installed, run `gradle wrapper --gradle-version 8.13` once (with a JDK and Android SDK installed), or let Android Studio configure the project. `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` work after creating the wrapper. This archive intentionally does **not** contain an unverified or fabricated Gradle wrapper binary.

**This chat environment does not contain an Android SDK or Gradle distribution, so APK compilation and device integration tests could not be performed.**

## 3. First run

1. Install and launch the app.
2. Paste the X Developer **Client ID** and press **Save Client ID**.
3. Press **Connect X Account**; authorize access in the system browser. You must sign in to an X account; it does not need to be @nya0331.
4. Grant Android notification permission.
5. Press **Test Notification**, then **Choose Sound & Vibration** to configure the app's notification channel in Android settings.
6. Press **Check Now** to test real API access. A 401, 403, or 429 status is shown in the app as an error, **not OFFLINE**.
7. Enable **Monitoring**. The app arms seven nightly alarm targets.

The official GET lookup uses the numeric ID resolved from `GET /2/users/by/username/nya0331` and requests `space.fields=id,title,state,started_at,scheduled_start&expansions=creator_id`. It alerts only if the Space state is `live` and the returned creator ID matches the target.

## 4. Schedule and its limitations

| Target time (KST) | Eligible actual run time |
|---|---|
| 00:00 | 00:00–00:29:59 |
| 00:30 | 00:30–00:59:59 |
| 01:00 | 01:00–01:29:59 |
| 01:30 | 01:30–01:59:59 |
| 02:00 | 02:00–02:29:59 |
| 02:30 | 02:30–02:59:59 |
| 03:00 | 03:00–03:00:59 only |

**Important ambiguity:** the user's requirements include a 03:00 check *and* prohibit automatic requests after 03:00. This project treats **03:00:00 through 03:00:59 as the inclusive final minute**, and skips any more delayed delivery. This boundary is documented rather than silently extending monitoring to 03:30.

`setAndAllowWhileIdle` **does not guarantee exact 30-minute execution**. Android Doze, app standby, battery saver, OEM battery controls and WorkManager dispatch can delay or skip a scheduled check. The device cannot monitor while powered off or after the user explicitly force-stops the app. A Space shorter than the polling gap may be missed.

There is **no automatic network request outside the allowed window**. A manual **Check Now** request is permitted at any time. The last successful/attempted times are displayed, and all actual attempts are logged locally.

**Samsung Galaxy:** open **Settings → Apps → Nya Spaces Monitor → Battery** and select an available unrestricted/background-allowed setting if overnight checks are delayed. Check **Settings → Battery → Background usage limits** and ensure the app is not in sleeping/deep sleeping lists. Exact menu names differ by One UI version. Battery exceptions can improve reliability but cannot guarantee exact delivery.

## 5. How the implementation works

- `monitor/NightPlan.kt` — deterministic KST schedule; final boundary guard.
- `monitor/AlarmScheduler.kt` — seven one-shot inexact Doze-compatible alarms, daily re-arming, boot/time-change/package-update rescheduling.
- `monitor/SpaceWorker.kt` — short one-time WorkManager job, verifies the time window **again** before any request; no out-of-window retry.
- `auth/XOAuth.kt` — system-browser OAuth 2.0 Authorization Code + PKCE; refresh-token rotation.
- `data/SecretVault.kt` — local AES/GCM with Android Keystore.
- `network/XSpacesApi.kt` — official X API lookups; malformed/unverifiable creator IDs fail closed.
- `monitor/SpaceDetector.kt` — only new live Spaces for the verified creator; deduplication.
- `monitor/MonitorEngine.kt` — serialized checks, status update, notification dispatch.
- `notifications/SpaceNotifications.kt` — local high-importance sound/vibration channel; deep-link to X Space.
- `ui/MainActivity.kt` — dark-mode Compose UI, OAuth setup, manual test, history, settings, controls.

Notification IDs are marked as delivered in persistent storage **before** the Android notification is posted, providing at-most-once behavior when a process dies, with the rare tradeoff that a notification could be lost between committing the ID and posting it. If notifications are disabled, IDs are not reserved so a live Space can still be alerted on a later eligible check after permission is granted.

### Security limitations

- OAuth client ID is public; tokens are encrypted at rest but could be exposed on a compromised/rooted device.
- Custom-scheme redirects may be intercepted by a malicious app with a conflicting scheme; PKCE/state mitigate code misuse. Using an X-approved verified HTTPS App Link would be stronger but needs ownership of an HTTPS domain, which conflicts with the no-server simplicity goal.
- No credentials are transmitted to any destination except X's official OAuth/API endpoints.
- No backups of sensitive app data are allowed (`allowBackup=false`).

## 6. Testing

### Already run in this environment

`./smoke/run_smoke.sh`

Output: `PASS: schedule and detection smoke checks`

These tests compile and run only the pure Kotlin scheduler/detection rules, **not Android platform integration**.

### Run locally after Android Studio setup

`./gradlew testDebugUnitTest`

This runs pure unit tests covering seven schedule slots, midnight rollover, cutoff guards, creator verification, LIVE versus scheduled, duplicate IDs, and Space URLs.

### Device integration test checklist (not yet executed)

- Grant/revoke POST_NOTIFICATIONS and verify test alert with sound/vibration.
- Connect OAuth from the actual phone; resolve user ID.
- Use Check Now; verify HTTP 200, and correct LIVE/OFFLINE behavior.
- Verify no alert for a scheduled Space or different creator.
- Trigger a live test with an actual permitted host/controlled fixture, and confirm notification deep link.
- Lock the screen for an overnight monitoring window and inspect check history/timestamps.
- Force Android Doze with `adb shell dumpsys deviceidle force-idle` and monitor delayed work; reset with `adb shell dumpsys deviceidle unforce`.
- Reboot and verify alarms get rearmed.
- Check failure states for 401/403/429 and temporary network unavailability.
- Confirm the 03:00:59 cutoff and no automatic daytime network activity.

## 7. Troubleshooting

- **401:** OAuth token invalid or expired; disconnect/reconnect X.
- **403:** X app permission, API access tier, billing or scope might prohibit the lookup; check Developer Console.
- **429:** API rate-limited; the app records UNKNOWN and does not spam retries. Reevaluate allowed polling cadence.
- **UNKNOWN:** not necessarily offline; inspect last error.
- **No notifications:** grant runtime permission and enable sound/vibration on the app's Android channel; check system DND and mute.
- **No overnight activity:** Doze/OEM delay, app force-stop, battery restrictions, or no connected OAuth session.

## Source and policy references

- X Spaces Lookup: https://docs.x.com/x-api/spaces/get-spaces-by-creator-ids
- X Spaces overview: https://docs.x.com/x-api/spaces/introduction
- X API pricing: https://docs.x.com/x-api/getting-started/pricing
- Android alarm rules: https://developer.android.com/develop/background-work/services/alarms
- Android WorkManager: https://developer.android.com/reference/androidx/work/package-summary

## Build APK without installing Android Studio (GitHub Actions)

A `.github/workflows/android-apk.yml` workflow has been added. To use it:

1. Create a private GitHub repository and upload the **contents** of this source project (including the `.github` folder) to its `main` branch.
2. Open the GitHub repository's **Actions** tab and select **Build Android APK**.
3. Select **Run workflow** (or let the automatic `main` push trigger it).
4. When the workflow completes successfully, download the **NyaSpacesMonitor-debug-APK** artifact; extract `app-debug.apk`, then transfer it to your Android device and install it.
5. On the phone, add your own X Developer Client ID, authorize access, and verify **Check Now**. Live API functionality is not guaranteed until real permissions are tested.

The debug APK is signed using Android's build-system debug key, not a production release key. The GitHub workflow must be run in a network-enabled runner and is **not** evidence that compilation was performed in this conversation.

This environment was checked for Android SDK/Gradle and for outbound downloading; Android SDK/Gradle were absent and external download attempts failed. Accordingly, no actual APK could be produced or verified locally.
