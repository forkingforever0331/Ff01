#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/smoke
kotlinc app/src/main/java/com/example/nyaspaces/monitor/NightPlan.kt \
  app/src/main/java/com/example/nyaspaces/monitor/SpaceDetector.kt \
  smoke/Smoke.kt -include-runtime -d build/smoke/smoke.jar
java -jar build/smoke/smoke.jar
