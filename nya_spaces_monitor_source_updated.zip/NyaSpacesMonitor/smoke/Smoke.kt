import com.example.nyaspaces.monitor.NightPlan
import com.example.nyaspaces.monitor.SpaceCandidate
import com.example.nyaspaces.monitor.SpaceDetector
import java.time.LocalDateTime

fun main() {
    require(NightPlan.slots.size == 7)
    val start = LocalDateTime.parse("2026-11-04T02:30:00").atZone(NightPlan.zone).toInstant().toEpochMilli()
    require(NightPlan.isAllowed(5, start, start + 20_000))
    require(NightPlan.isAllowed(5, start, start + 29 * 60_000 + 59_000))
    val lastSlot = LocalDateTime.parse("2026-11-04T03:00:00")
        .atZone(NightPlan.zone).toInstant().toEpochMilli()
    require(NightPlan.isAllowed(6, lastSlot, lastSlot + 59_000))
    require(!NightPlan.isAllowed(6, lastSlot, lastSlot + 60_000))
    require(!NightPlan.isAllowed(5, start, start + 30 * 60_000))
    val matching = SpaceDetector.newLive(listOf(
        SpaceCandidate("a", "123", "live", "Live", ""),
        SpaceCandidate("b", "456", "live", "Wrong user", ""),
        SpaceCandidate("c", "123", "scheduled", "Scheduled", "")
    ), "123", emptySet())
    require(matching.single().id == "a")
    require(SpaceDetector.newLive(matching, "123", setOf("a")).isEmpty())
    println("PASS: schedule and detection smoke checks")
}
