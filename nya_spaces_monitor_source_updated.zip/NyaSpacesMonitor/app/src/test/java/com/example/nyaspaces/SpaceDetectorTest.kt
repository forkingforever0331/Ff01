package com.example.nyaspaces

import com.example.nyaspaces.monitor.SpaceCandidate
import com.example.nyaspaces.monitor.SpaceDetector
import org.junit.Assert.*
import org.junit.Test

class SpaceDetectorTest {
    private fun space(id: String, creator: String = "123", state: String = "live") =
        SpaceCandidate(id, creator, state, "Example", "2026-11-04T00:00:00Z")
    @Test fun onlyCorrectCreatorAndLiveStateAreIncluded() {
        val actual = SpaceDetector.newLive(listOf(space("1"), space("2", "456"), space("3", state = "scheduled")), "123", emptySet())
        assertEquals(listOf("1"), actual.map { it.id })
    }
    @Test fun deduplicatesAndRecognizesSubsequentSpaces() {
        val actual = SpaceDetector.newLive(listOf(space("1"), space("1"), space("2")), "123", setOf("1"))
        assertEquals(listOf("2"), actual.map { it.id })
    }
    @Test fun createsCorrectSpaceLink() {
        assertEquals("https://x.com/i/spaces/987", space("987").url)
    }
}
