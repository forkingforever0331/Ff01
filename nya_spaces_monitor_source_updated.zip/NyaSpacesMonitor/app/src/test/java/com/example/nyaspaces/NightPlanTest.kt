package com.example.nyaspaces

import com.example.nyaspaces.monitor.NightPlan
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime

class NightPlanTest {
    private fun instant(s: String) = LocalDateTime.parse(s).atZone(NightPlan.zone).toInstant().toEpochMilli()

    @Test fun exactlySevenNightlySlots() {
        assertEquals(listOf("00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00"),
            NightPlan.slots.map { it.toString().padEnd(5, '0') })
    }
    @Test fun nextSlotBeforeAndAfter() {
        assertEquals(instant("2026-11-04T00:00:00"), NightPlan.nextTime(0, instant("2026-11-03T23:59:59")))
        assertEquals(instant("2026-11-05T00:00:00"), NightPlan.nextTime(0, instant("2026-11-04T00:01:00")))
    }
    @Test fun delayedChecksCannotRunOutsideTheirSlots() {
        val slot = instant("2026-11-04T00:30:00")
        assertTrue(NightPlan.isAllowed(1, slot, instant("2026-11-04T00:59:59")))
        assertFalse(NightPlan.isAllowed(1, slot, instant("2026-11-04T01:00:00")))
        assertFalse(NightPlan.isAllowed(1, slot, instant("2026-11-04T00:29:59")))
    }
    @Test fun threeAmBoundaryHasOneMinuteGraceOnly() {
        val slot = instant("2026-11-04T03:00:00")
        assertTrue(NightPlan.isAllowed(6, slot, instant("2026-11-04T03:00:50")))
        assertFalse(NightPlan.isAllowed(6, slot, instant("2026-11-04T03:01:00")))
        assertFalse(NightPlan.isAllowed(6, slot, instant("2026-11-05T03:00:20")))
    }
}
