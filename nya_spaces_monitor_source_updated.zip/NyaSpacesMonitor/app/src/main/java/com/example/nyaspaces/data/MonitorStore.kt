package com.example.nyaspaces.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ordinary non-secret configuration and persistent deduplication records. */
class MonitorStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("monitor_state", Context.MODE_PRIVATE)
    private val gate = lock

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(value) { prefs.edit().putBoolean("enabled", value).commit() }

    var clientId: String
        get() = prefs.getString("client_id", "") ?: ""
        set(value) { prefs.edit().putString("client_id", value.trim()).commit() }

    var creatorId: String
        get() = prefs.getString("creator_id", "") ?: ""
        set(value) { prefs.edit().putString("creator_id", value).commit() }

    var lastStatus: String
        get() = prefs.getString("last_status", "UNKNOWN") ?: "UNKNOWN"
        set(value) { prefs.edit().putString("last_status", value).commit() }

    var lastError: String
        get() = prefs.getString("last_error", "") ?: ""
        set(value) { prefs.edit().putString("last_error", value.take(300)).commit() }

    var lastCheck: Long
        get() = prefs.getLong("last_check", 0)
        set(value) { prefs.edit().putLong("last_check", value).commit() }

    var rateLimitUntil: Long
        get() = prefs.getLong("rate_limit_until", 0)
        set(value) { prefs.edit().putLong("rate_limit_until", value).commit() }

    var lastSuccess: Long
        get() = prefs.getLong("last_success", 0)
        set(value) { prefs.edit().putLong("last_success", value).commit() }

    var liveTitle: String
        get() = prefs.getString("live_title", "") ?: ""
        set(value) { prefs.edit().putString("live_title", value).commit() }

    var liveId: String
        get() = prefs.getString("live_id", "") ?: ""
        set(value) { prefs.edit().putString("live_id", value).commit() }

    private fun notifiedList(): List<String> {
        val array = JSONArray(prefs.getString("notified_ids", "[]"))
        return (0 until array.length()).map { array.getString(it) }
    }

    fun notifiedIds(): Set<String> = synchronized(gate) { notifiedList().toSet() }

    /** Returns false if previously notified; commit before delivery makes alerting at-most-once. */
    fun reserveNotification(id: String): Boolean = synchronized(gate) {
        val current = notifiedList()
        if (id in current) return@synchronized false
        prefs.edit().putString("notified_ids", JSONArray((current + id).takeLast(300)).toString()).commit()
    }

    fun addHistory(message: String) = synchronized(gate) {
        val existing = JSONArray(prefs.getString("history", "[]"))
        val lines = (0 until existing.length()).map { existing.getString(it) }
        prefs.edit().putString("history", JSONArray((listOf(message) + lines).take(40)).toString()).commit()
    }

    fun history(): List<String> = synchronized(gate) {
        val array = JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).map { array.getString(it) }
    }

    fun recordSuccess(time: Long, live: SpaceCandidateView?) {
        prefs.edit()
            .putLong("last_check", time)
            .putLong("last_success", time)
            .putString("last_error", "")
            .putString("last_status", if (live == null) "OFFLINE" else "LIVE")
            .putString("live_id", live?.id ?: "")
            .putString("live_title", live?.title ?: "")
            .commit()
        addHistory("${com.example.nyaspaces.monitor.NightPlan.format(time)}  •  ${if (live == null) "OFFLINE" else "LIVE: ${live.title}"}")
    }

    fun recordFailure(time: Long, message: String) {
        prefs.edit().putLong("last_check", time).putString("last_status", "UNKNOWN")
            .putString("last_error", message.take(300)).putString("live_id", "").putString("live_title", "").commit()
        addHistory("${com.example.nyaspaces.monitor.NightPlan.format(time)}  •  ERROR: ${message.take(100)}")
    }

    companion object { private val lock = Any() }
}

data class SpaceCandidateView(val id: String, val title: String)
