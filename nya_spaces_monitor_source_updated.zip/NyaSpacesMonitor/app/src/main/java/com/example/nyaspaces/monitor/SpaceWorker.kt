package com.example.nyaspaces.monitor

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.nyaspaces.data.MonitorStore

class SpaceWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val index = inputData.getInt("slot_index", -1)
        val scheduled = inputData.getLong("slot_time", -1L)
        if (index !in NightPlan.slots.indices || !MonitorStore(applicationContext).enabled) return Result.success()
        if (!NightPlan.isAllowed(index, scheduled, System.currentTimeMillis())) return Result.success()
        // One request attempt per eligible slot. A failed attempt is reported as UNKNOWN.
        // No retries outside the window.
        MonitorEngine.check(applicationContext, index to scheduled)
        return Result.success()
    }
}
