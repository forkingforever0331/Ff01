package com.example.nyaspaces.monitor

import android.content.Context
import com.example.nyaspaces.data.MonitorStore
import com.example.nyaspaces.data.SpaceCandidateView
import com.example.nyaspaces.network.XSpacesApi
import com.example.nyaspaces.network.ApiException
import com.example.nyaspaces.notifications.SpaceNotifications
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Serializes manual and automatic checks in one app process. */
object MonitorEngine {
    private val mutex = Mutex()

    suspend fun check(context: Context, slot: Pair<Int, Long>? = null): String = mutex.withLock {
        withContext(Dispatchers.IO) {
            val store = MonitorStore(context)
            val now = System.currentTimeMillis()
            try {
                val permitted = { slot == null || NightPlan.isAllowed(slot.first, slot.second, System.currentTimeMillis()) }
                check(permitted()) { "Scheduled window elapsed before API request" }
                if (store.rateLimitUntil > System.currentTimeMillis()) {
                    error("X API rate limit: next eligible time is ${NightPlan.format(store.rateLimitUntil)}")
                }
                val result = XSpacesApi(context).lookup(permitted)
                store.rateLimitUntil = 0L
                val live = result.filter { it.state == "live" && it.creatorId == store.creatorId }
                    .maxByOrNull { it.startedAt }
                store.recordSuccess(now, live?.let { SpaceCandidateView(it.id, it.title) })
                val newSpaces = SpaceDetector.newLive(result, store.creatorId, store.notifiedIds())
                for (space in newSpaces) {
                    if (!SpaceNotifications.isPermitted(context)) {
                        store.lastError = "Space detected but Android notifications are disabled. Grant permission."
                        continue
                    }
                    if (store.reserveNotification(space.id)) {
                        if (SpaceNotifications.sendSpace(context, space)) {
                            store.addHistory("🔴 Alert sent: ${space.title} (${space.id})")
                        } else {
                            store.lastError = "Could not post notification"
                        }
                    }
                }
                if (live != null) "LIVE: ${live.title}" else "OFFLINE: no live Space was found"
            } catch (e: Exception) {
                if (e is ApiException && e.status == 429) {
                    store.rateLimitUntil = maxOf(System.currentTimeMillis() + 30 * 60_000L, e.retryAtMillis)
                }
                val detail = e.message ?: e.javaClass.simpleName
                store.recordFailure(now, detail)
                "UNKNOWN: $detail"
            }
        }
    }
}
