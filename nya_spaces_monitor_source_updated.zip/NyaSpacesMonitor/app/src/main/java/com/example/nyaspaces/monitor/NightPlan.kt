package com.example.nyaspaces.monitor

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Pure, JVM-testable scheduling rules. Times are always in Korea, regardless of device time zone. */
object NightPlan {
    val zone: ZoneId = ZoneId.of("Asia/Seoul")
    val slots: List<LocalTime> = (0..6).map { LocalTime.of(it / 2, (it % 2) * 30) }

    fun nextTime(slotIndex: Int, afterMillis: Long): Long {
        val current = Instant.ofEpochMilli(afterMillis).atZone(zone)
        val today = current.toLocalDate().atTime(slots[slotIndex]).atZone(zone)
        return (if (today.toInstant().toEpochMilli() > afterMillis) today else today.plusDays(1))
            .toInstant().toEpochMilli()
    }

    fun nextAny(afterMillis: Long): Long = slots.indices.minOf { nextTime(it, afterMillis) }

    /**
     * Slots 00:00..02:30 may be delayed up to, but not including, the next slot.
     * The 03:00 boundary slot gets a 59-second grace in the same minute only.
     * No automatic HTTP call is allowed after 03:00:59 KST.
     */
    fun isAllowed(slotIndex: Int, scheduledMillis: Long, nowMillis: Long): Boolean {
        if (slotIndex !in slots.indices || nowMillis < scheduledMillis) return false
        val scheduled = Instant.ofEpochMilli(scheduledMillis).atZone(zone)
        val now = Instant.ofEpochMilli(nowMillis).atZone(zone)
        // Verify the original slot, not the current clock minute. Doze may deliver
        // 00:30's alarm at 00:45, which must remain eligible until 01:00.
        if (scheduled.toLocalDate() != now.toLocalDate() || scheduled.toLocalTime() != slots[slotIndex]) return false
        val deadline = if (slotIndex == 6) scheduledMillis + 60_000 else scheduledMillis + 30 * 60_000
        return nowMillis < deadline
    }

    fun format(epochMillis: Long): String = if (epochMillis == 0L) "Never" else
        Instant.ofEpochMilli(epochMillis).atZone(zone).toLocalDateTime().toString().replace('T', ' ') + " KST"
}
