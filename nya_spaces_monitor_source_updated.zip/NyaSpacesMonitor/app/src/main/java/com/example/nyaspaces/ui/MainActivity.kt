package com.example.nyaspaces.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.nyaspaces.auth.XOAuth
import com.example.nyaspaces.data.MonitorStore
import com.example.nyaspaces.monitor.AlarmScheduler
import com.example.nyaspaces.monitor.MonitorEngine
import com.example.nyaspaces.monitor.NightPlan
import com.example.nyaspaces.notifications.SpaceNotifications
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var version by mutableIntStateOf(0)
    private fun refresh() { version++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SpaceNotifications.createChannel(this)
        // Re-arm the next seven checks after app update, first launch, or configuration changes.
        AlarmScheduler.rescheduleAll(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color(0xFF090C16), surface = Color(0xFF141B2A),
                primary = Color(0xFF94B8FF), onBackground = Color(0xFFEAF0FF),
                onSurface = Color(0xFFEAF0FF)
            )) { Home(version) }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    @Composable
    private fun Home(refreshVersion: Int) {
        val store = remember { MonitorStore(this) }
        val oauth = remember { XOAuth(this) }
        val scope = rememberCoroutineScope()
        var clientIdInput by remember { mutableStateOf(store.clientId) }
        var checking by remember { mutableStateOf(false) }
        var feedback by remember { mutableStateOf("") }
        // Re-read persistent state when the app returns from an OAuth redirect or after manual work.
        val enabled = remember(refreshVersion) { store.enabled }
        val signedIn = remember(refreshVersion) { oauth.signedIn() }
        val status = remember(refreshVersion) { store.lastStatus }
        val error = remember(refreshVersion) { store.lastError }
        val lastCheck = remember(refreshVersion) { store.lastCheck }
        val lastSuccess = remember(refreshVersion) { store.lastSuccess }
        val liveId = remember(refreshVersion) { store.liveId }
        val liveTitle = remember(refreshVersion) { store.liveTitle }
        val history = remember(refreshVersion) { store.history() }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            refresh()
        }

        Scaffold(containerColor = MaterialTheme.colorScheme.background) { insets ->
            Column(Modifier.fillMaxSize().padding(insets).verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("X SPACES", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                Text("Nya Spaces Monitor", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("On-device monitoring • No backend • Asia/Seoul", style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFB5C1D9))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("MONITORING @nya0331", fontWeight = FontWeight.Bold)
                                Text("12:00 AM – 3:00 AM · every 30 min", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = enabled, onCheckedChange = { on ->
                                if (on && !oauth.signedIn()) {
                                    feedback = "Connect your X account before enabling monitoring."
                                } else {
                                    store.enabled = on
                                    AlarmScheduler.rescheduleAll(this@MainActivity)
                                    feedback = if (on) "Monitoring enabled" else "Monitoring paused"
                                }
                                refresh()
                            })
                        }
                        HorizontalDivider()
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Current result", style = MaterialTheme.typography.titleSmall)
                            StatusTag(status)
                        }
                        if (status == "LIVE" && liveId.isNotBlank()) {
                            Text(liveTitle.ifBlank { "Live Space" })
                            Button(onClick = { open("https://x.com/i/spaces/$liveId") }) { Text("Join Live Space") }
                        }
                        InfoLine("Last check", NightPlan.format(lastCheck))
                        InfoLine("Last successful", NightPlan.format(lastSuccess))
                        InfoLine("Next target", if (enabled) NightPlan.format(NightPlan.nextAny(System.currentTimeMillis())) else "Monitoring off")
                        if (error.isNotBlank()) Text("Issue: $error", color = Color(0xFFFFA1A1), style = MaterialTheme.typography.bodySmall)
                        if (feedback.isNotBlank()) Text(feedback, style = MaterialTheme.typography.bodySmall)
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !checking && signedIn,
                            onClick = {
                                checking = true
                                scope.launch {
                                    feedback = MonitorEngine.check(this@MainActivity)
                                    checking = false
                                    refresh()
                                }
                            }
                        ) {
                            if (checking) CircularProgressIndicator(modifier = Modifier.height(18.dp), strokeWidth = 2.dp)
                            else Text("Check Now")
                        }
                        Text("Manual checks may run at any hour. Automatic checks run only during the nightly window.",
                            style = MaterialTheme.typography.bodySmall, color = Color(0xFFB5C1D9))
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("X API connection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(if (signedIn) "Connected using OAuth 2.0 PKCE" else "Not connected — enter your developer Client ID and sign in.",
                            style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = clientIdInput, onValueChange = { clientIdInput = it },
                            label = { Text("X Developer Client ID (public)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(onClick = {
                            val proposed = clientIdInput.trim()
                            if (proposed.isBlank()) { feedback = "Client ID cannot be empty" }
                            else {
                                if (proposed != store.clientId) {
                                    oauth.disconnect()
                                    store.creatorId = ""
                                    store.enabled = false
                                    AlarmScheduler.rescheduleAll(this@MainActivity)
                                }
                                store.clientId = proposed
                                feedback = "Client ID saved locally"
                            }
                            refresh()
                        }) { Text("Save Client ID") }
                        if (!signedIn) {
                            Button(onClick = {
                                try { oauth.openLogin(this@MainActivity) }
                                catch (e: Exception) { feedback = e.message.orEmpty() }
                            }, enabled = store.clientId.isNotBlank()) { Text("Connect X Account") }
                        } else {
                            OutlinedButton(onClick = {
                                oauth.disconnect()
                                store.enabled = false
                                AlarmScheduler.rescheduleAll(this@MainActivity)
                                feedback = "Disconnected"
                                refresh()
                            }) { Text("Disconnect X") }
                        }
                        Text("Requires an X Developer app with Spaces API access. The Client ID is not a secret; OAuth tokens are encrypted using Android Keystore.",
                            style = MaterialTheme.typography.bodySmall, color = Color(0xFFB5C1D9))
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Local notifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(if (SpaceNotifications.isPermitted(this@MainActivity)) "Notifications enabled" else "Notification permission or system channel is disabled",
                            style = MaterialTheme.typography.bodySmall)
                        if (Build.VERSION.SDK_INT >= 33) {
                            OutlinedButton(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                                Text("Request Notification Permission")
                            }
                        }
                        OutlinedButton(onClick = { SpaceNotifications.openChannelSettings(this@MainActivity) }) {
                            Text("Choose Sound & Vibration")
                        }
                        OutlinedButton(onClick = {
                            val ok = SpaceNotifications.sendTest(this@MainActivity)
                            Toast.makeText(this@MainActivity, if (ok) "Test notification sent" else "Enable notifications first", Toast.LENGTH_SHORT).show()
                        }) { Text("Send Test Notification") }
                        Text("Android controls sound and vibration through the notification channel. System mute and Do Not Disturb still apply.",
                            style = MaterialTheme.typography.bodySmall, color = Color(0xFFB5C1D9))
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Recent activity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (history.isEmpty()) Text("No checks yet", style = MaterialTheme.typography.bodySmall)
                        history.take(12).forEachIndexed { idx, message ->
                            if (idx > 0) HorizontalDivider()
                            Text(message, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                OutlinedButton(onClick = { open("https://x.com/nya0331") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Open @nya0331 on X")
                }
                Text("Timing is approximate: Android Doze may delay checks, and a short Space may end between checks. The 03:00 boundary check may be skipped if delayed.",
                    color = Color(0xFFB5C1D9), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    @Composable
    private fun InfoLine(label: String, value: String) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = Color(0xFFB5C1D9))
            Text(value, style = MaterialTheme.typography.bodySmall)
        }
    }

    @Composable
    private fun StatusTag(status: String) {
        val color = when (status) {
            "LIVE" -> Color(0xFFFF6276)
            "OFFLINE" -> Color(0xFF95ADCC)
            else -> Color(0xFFFFC880)
        }
        Surface(color = color.copy(alpha = .15f), shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
            Text(status, color = color, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        }
    }

    private fun open(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
