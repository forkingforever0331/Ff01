package com.example.nyaspaces.monitor

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.nyaspaces.data.MonitorStore

/** Inexact Doze-compatible alarms; no exact-alarm permission, no continuous service. */
object AlarmScheduler {
    private fun operation(context: Context, index: Int, scheduledTime: Long): PendingIntent =
        PendingIntent.getBroadcast(context, 20_000 + index,
            Intent(context, AlarmReceiver::class.java)
                .putExtra("slot_index", index)
                .putExtra("slot_time", scheduledTime),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun rescheduleAll(context: Context) {
        for (index in NightPlan.slots.indices) schedule(context, index)
    }

    fun schedule(context: Context, index: Int) {
        val manager = context.getSystemService(AlarmManager::class.java)
        val scheduled = NightPlan.nextTime(index, System.currentTimeMillis())
        val pending = operation(context, index, scheduled)
        manager.cancel(pending)
        if (MonitorStore(context).enabled) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, scheduled, pending)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val index = intent.getIntExtra("slot_index", -1)
        if (index !in NightPlan.slots.indices) return
        // Read the original alarm timestamp. Reconstructing it from today's date
        // could incorrectly treat a very late alarm as a new-day check.
        val scheduled = intent.getLongExtra("slot_time", -1L)
        // The next day's slot is armed immediately, even if work is subsequently delayed.
        AlarmScheduler.schedule(context, index)
        if (!MonitorStore(context).enabled) return
        val now = System.currentTimeMillis()
        // A delivery after its eligible slot is skipped; never make daytime automatic requests.
        if (!NightPlan.isAllowed(index, scheduled, now)) return
        val work = OneTimeWorkRequestBuilder<SpaceWorker>()
            .setInputData(workDataOf("slot_index" to index, "slot_time" to scheduled))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "night_${index}_${scheduled}", ExistingWorkPolicy.KEEP, work
        )
    }
}

class RearmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> AlarmScheduler.rescheduleAll(context)
        }
    }
}
