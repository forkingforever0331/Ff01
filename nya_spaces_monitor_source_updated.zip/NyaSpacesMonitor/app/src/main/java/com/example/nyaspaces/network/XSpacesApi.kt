package com.example.nyaspaces.network

import android.content.Context
import com.example.nyaspaces.auth.XOAuth
import com.example.nyaspaces.data.MonitorStore
import com.example.nyaspaces.monitor.SpaceCandidate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class XSpacesApi(private val context: Context) {
    private val store = MonitorStore(context)
    private val auth = XOAuth(context)

    suspend fun lookup(canRequest: () -> Boolean = { true }): List<SpaceCandidate> = withContext(Dispatchers.IO) {
        check(canRequest()) { "Scheduled monitoring window elapsed" }
        val token = auth.accessToken(canRequest)
        val userId = store.creatorId.ifBlank {
            check(canRequest()) { "Scheduled monitoring window elapsed before account lookup" }
            val user = HttpApi.request("https://api.x.com/2/users/by/username/nya0331?user.fields=id,username", token)
                .optJSONObject("data") ?: error("X did not return the target account")
            if (!user.optString("username").equals("nya0331", ignoreCase = true))
                error("Unexpected account from X API")
            val id = user.getString("id")
            require(id.matches(Regex("[0-9]{1,19}"))) { "Invalid X user ID" }
            store.creatorId = id
            id
        }
        val url = "https://api.x.com/2/spaces/by/creator_ids?user_ids=$userId" +
            "&space.fields=id,title,state,started_at,scheduled_start&expansions=creator_id"
        check(canRequest()) { "Scheduled monitoring window elapsed before Space lookup" }
        val json = HttpApi.request(url, token)
        val errors = json.optJSONArray("errors")
        if (errors != null && errors.length() > 0) {
            throw IllegalStateException("X returned a partial/failed Spaces lookup")
        }
        val data = json.optJSONArray("data") ?: return@withContext emptyList()
        (0 until data.length()).map { idx ->
            val obj = data.getJSONObject(idx)
            // No creator ID means the owner could not be independently verified: fail closed.
            require(obj.has("creator_id")) { "X response omitted creator_id; cannot verify host" }
            SpaceCandidate(
                id = obj.getString("id"),
                creatorId = obj.getString("creator_id"),
                state = obj.optString("state", "unknown"),
                title = obj.optString("title", "Untitled Space"),
                startedAt = obj.optString("started_at", "")
            )
        }
    }
}
