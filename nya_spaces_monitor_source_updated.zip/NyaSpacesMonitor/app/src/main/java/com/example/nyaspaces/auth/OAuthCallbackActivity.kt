package com.example.nyaspaces.auth

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.example.nyaspaces.data.MonitorStore
import com.example.nyaspaces.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OAuthCallbackActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data
        CoroutineScope(Dispatchers.Main).launch {
            val store = MonitorStore(this@OAuthCallbackActivity)
            try {
                requireNotNull(uri) { "Missing callback URI" }
                XOAuth(this@OAuthCallbackActivity).completeRedirect(uri)
                store.lastError = ""
                store.addHistory("X login successful")
            } catch (e: Exception) {
                store.lastError = "Login failed: ${e.message.orEmpty().take(180)}"
                store.addHistory("Login failed: ${e.message.orEmpty().take(100)}")
            }
            startActivity(Intent(this@OAuthCallbackActivity, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
    }
}
