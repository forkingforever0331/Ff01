package com.example.nyaspaces.monitor

/** No dependence on Android or X networking; safe to test on a plain JVM. */
data class SpaceCandidate(
    val id: String,
    val creatorId: String,
    val state: String,
    val title: String,
    val startedAt: String
) {
    val url: String get() = "https://x.com/i/spaces/$id"
}

object SpaceDetector {
    fun newLive(spaces: List<SpaceCandidate>, requiredCreatorId: String, alreadyAlerted: Set<String>): List<SpaceCandidate> =
        spaces.asSequence()
            .filter { it.id.isNotBlank() && it.creatorId == requiredCreatorId && it.state == "live" }
            .filterNot { it.id in alreadyAlerted }
            .distinctBy { it.id }
            .sortedBy { it.startedAt }
            .toList()
}
