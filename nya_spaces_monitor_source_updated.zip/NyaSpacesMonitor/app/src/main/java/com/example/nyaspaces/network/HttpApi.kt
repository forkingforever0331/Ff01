package com.example.nyaspaces.network

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ApiException(val status: Int, reason: String, val retryAtMillis: Long = 0L) :
    Exception("HTTP $status: ${reason.take(180)}")

object HttpApi {
    fun form(params: Map<String, String>): String = params.entries.joinToString("&") {
        "${encode(it.key)}=${encode(it.value)}"
    }

    fun encode(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun request(url: String, bearer: String? = null, postForm: Map<String, String>? = null): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 8_000
        connection.readTimeout = 8_000
        connection.instanceFollowRedirects = false
        connection.setRequestProperty("Accept", "application/json")
        if (bearer != null) connection.setRequestProperty("Authorization", "Bearer $bearer")
        if (postForm != null) {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
        }
        try {
            if (postForm != null) connection.outputStream.use { it.write(form(postForm).toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val bytes = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText().take(128_000) } ?: ""
            if (status !in 200..299) {
                val description = try {
                    val obj = JSONObject(bytes)
                    obj.optString("detail", obj.optString("title", obj.optString("error_description", obj.optString("error", "Request failed"))))
                } catch (_: Exception) { "Request failed" }
                val resetSeconds = connection.getHeaderField("x-rate-limit-reset")?.toLongOrNull()
                val retrySeconds = connection.getHeaderField("Retry-After")?.toLongOrNull()
                val retryAt = when {
                    resetSeconds != null -> resetSeconds * 1000L
                    retrySeconds != null -> System.currentTimeMillis() + retrySeconds * 1000L
                    else -> 0L
                }
                throw ApiException(status, description, retryAt)
            }
            return JSONObject(bytes)
        } finally { connection.disconnect() }
    }
}
