package com.example.nyaspaces

import android.app.Application
import com.example.nyaspaces.notifications.SpaceNotifications

class NyaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        SpaceNotifications.createChannel(this)
    }
}
