package com.example.nyaspaces.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.nyaspaces.R
import com.example.nyaspaces.monitor.SpaceCandidate

object SpaceNotifications {
    const val CHANNEL = "live_spaces_v1"

    fun createChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL, "New X Spaces", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Sound and vibration when @nya0331 starts a Space"
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)
    }

    fun isPermitted(context: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            && context.getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    fun sendSpace(context: Context, space: SpaceCandidate): Boolean {
        if (!isPermitted(context)) return false
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(space.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pending = PendingIntent.getActivity(context, space.id.hashCode(), intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_space)
            .setContentTitle("🔴 @nya0331 Started a Space!")
            .setContentText(space.title.ifBlank { "A live X Space has started. Tap to join!" })
            .setStyle(Notification.BigTextStyle().bigText(space.title.ifBlank { "Tap to join the live Space" }))
            .setCategory(Notification.CATEGORY_EVENT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(space.id.hashCode(), notification)
        return true
    }

    fun sendTest(context: Context): Boolean {
        if (!isPermitted(context)) return false
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://x.com/nya0331"))
        val pending = PendingIntent.getActivity(context, 99001, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_space)
            .setContentTitle("🔔 Test notification")
            .setContentText("This is a local test, not a real live Space")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(99001, notification)
        return true
    }

    fun openChannelSettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .putExtra(Settings.EXTRA_CHANNEL_ID, CHANNEL)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
