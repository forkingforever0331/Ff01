package com.example.nyaspaces.auth

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import com.example.nyaspaces.data.MonitorStore
import com.example.nyaspaces.data.SecretVault
import com.example.nyaspaces.network.HttpApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

/** OAuth 2.0 Authorization Code + PKCE for public mobile clients. */
class XOAuth(private val context: Context) {
    private val vault = SecretVault(context)
    private val store = MonitorStore(context)

    fun signedIn(): Boolean = vault.read("token")?.optString("access_token")?.isNotBlank() == true
    fun disconnect() { vault.remove("token"); vault.remove("pending") }

    fun openLogin(activity: Activity) {
        val clientId = store.clientId
        require(clientId.isNotBlank()) { "Enter the Client ID from your X developer app first." }
        val verifier = randomBytes(32)
        val state = randomBytes(24)
        vault.write("pending", JSONObject().put("verifier", verifier).put("state", state).put("created", System.currentTimeMillis()))
        val challenge = Base64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.UTF_8)),
            Base64.NO_PADDING or Base64.NO_WRAP or Base64.URL_SAFE
        )
        val uri = Uri.parse("https://x.com/i/oauth2/authorize").buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", clientId)
            .appendQueryParameter("redirect_uri", REDIRECT)
            .appendQueryParameter("scope", "space.read users.read tweet.read offline.access")
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .build()
        activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    suspend fun completeRedirect(uri: Uri) = withContext(Dispatchers.IO) {
        if (uri.scheme != "com.example.nyaspaces" || uri.host != "oauth" || uri.path != "/callback")
            error("Unexpected OAuth redirect URI")
        val pending = vault.read("pending") ?: error("Login session expired; please sign in again")
        if (System.currentTimeMillis() - pending.optLong("created", 0) > 600_000) error("Login expired; try again")
        if (uri.getQueryParameter("state") != pending.optString("state")) error("OAuth state mismatch")
        val oauthError = uri.getQueryParameter("error")
        if (!oauthError.isNullOrEmpty()) error("X authorization declined: $oauthError")
        val code = uri.getQueryParameter("code") ?: error("No authorization code was returned")
        // Clear only after state verification, to prevent replay.
        vault.remove("pending")
        val token = HttpApi.request(TOKEN_ENDPOINT, postForm = mapOf(
            "grant_type" to "authorization_code",
            "code" to code,
            "redirect_uri" to REDIRECT,
            "code_verifier" to pending.getString("verifier"),
            "client_id" to store.clientId
        ))
        saveTokens(token)
    }

    suspend fun accessToken(canRequest: () -> Boolean = { true }): String = tokenMutex.withLock {
        withContext(Dispatchers.IO) {
            val token = vault.read("token") ?: error("Sign in to X first")
            if (token.optLong("expires_at") > System.currentTimeMillis() + 120_000)
                return@withContext token.getString("access_token")
            val refresh = token.optString("refresh_token")
            if (refresh.isBlank()) error("X session expired. Sign in again.")
            check(canRequest()) { "Scheduled monitoring window elapsed before token refresh" }
            val refreshed = HttpApi.request(TOKEN_ENDPOINT, postForm = mapOf(
                "grant_type" to "refresh_token",
                "refresh_token" to refresh,
                "client_id" to store.clientId
            ))
            if (!refreshed.has("refresh_token")) refreshed.put("refresh_token", refresh)
            saveTokens(refreshed)
            refreshed.getString("access_token")
        }
    }

    private fun saveTokens(json: JSONObject) {
        require(json.optString("access_token").isNotBlank()) { "X did not provide an access token" }
        json.put("expires_at", System.currentTimeMillis() + json.optLong("expires_in", 7200) * 1_000)
        vault.write("token", json)
    }

    private fun randomBytes(count: Int): String = ByteArray(count).also { SecureRandom().nextBytes(it) }.let {
        Base64.encodeToString(it, Base64.NO_PADDING or Base64.NO_WRAP or Base64.URL_SAFE)
    }

    companion object {
        const val REDIRECT = "com.example.nyaspaces://oauth/callback"
        private const val TOKEN_ENDPOINT = "https://api.x.com/2/oauth2/token"
        private val tokenMutex = Mutex()
    }
}
